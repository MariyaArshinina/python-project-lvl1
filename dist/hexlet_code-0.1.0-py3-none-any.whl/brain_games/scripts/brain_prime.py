#!/usr/bin/env python3
from brain_games.games.greet_prime import greet_prime


def main():
    print('Welcome to the Brain Games!')
    greet_prime()

    if __name__ == '__main__':
        main()
